
=================
Table of Contents
=================

   1.  Installing PPD Files

   2.  Configuring Printers in CUPS
       2.1  Define your printer using the CUPS Web Interface
       2.2  Define your printer using the CUPS command line
 
   3.  Print using CUPS command line print options 

   4.  Known Issues
       4.1  Localization.
       4.2  Printing text files with Red Flag 6.0 and Redhat 5.0.
       4.3  Printing text files with Linpus 9.6.
       4.4  Printing using Print and Hold option and Fax option.
       4.5  Printing using Custom paper sizes.
       4.6  Printing via the Commandline on OS with CUPS 1.4 and higher.
       4.7  Printing on OS with CUPS 1.1 and below.
       4.8  Printing PDF file on Fedora OS with CUPS 1.4.3 and higher.
       4.9  Printing via the Commandline and Collate option
       4.10  Printing documents with OpenOffice 3.2
       4.11  Printing Adobe PS 3.0 files using Document Viewer on Ubuntu 10.10
       4.12  Possible solution for a print output that is clipped.
       4.13  Printing files with Mirror option activated

========================
1. Installing PPD Files
========================

   See Readme-Install.txt for installation directions.


================================
2.  Configuring Printers in CUPS
================================

   ------------------------------------------------------
   2.1  Define your printer using the CUPS Web Interface.
   ------------------------------------------------------

     1.  Open a Web Browser and access the CUPS Administration Page by
         using the following URL and select continue.

         http://localhost:631/admin

         When prompted for username, use root and root's password.  On
         SuSE systems, you'll need to create an account with lppasswd
         and use this account instead of root. 

     2.  Select 'Add Printer',  enter a queue name in the Name field
         and select continue.

     3.  Select 'AppSocket/HP JetDirect' for the Device type and enter
         the following Device URI and select continue.

           socket://printer_hostname:9100 

         Replace 'printer_hostname' with the Printer's Hostname or IP 
         Address.

     4.  Choose 'Lexmark' from the Make list followed by your printer 
         model from the Model list and select Continue.

         If you intend to send fax from your computer using your fax-capable
         printer, choose either the Fax or PostScript variant of the printer
         model you are installing and select Continue. This is only available
         for OSes with CUPS 1.4 or later.

         This will create the printer queue.  After the print queue 
         has been created, you can set the queue defaults, by selecting 
         'Printers' and 'Configure Printer'.
   

   -----------------------------------------------------
   2.2  Define your printer using the CUPS command line.
   -----------------------------------------------------

     1.  Create the queue with the lpadmin command.

         # lpadmin -p queue_name -v socket://printer_hostname:9100 \
              -P /usr/share/cups/model/Lexmark_PPD/Lexmark.ppd
	
	 or 

         # lpadmin -p queue_name -v socket://printer_hostname:9100 \
              -P /usr/share/ppd/Lexmark_PPD/Lexmark.ppd

     2.  Enable the queue and set the queue to accept print jobs.

	 If the version of your CUPS is lower than 1.2 
           # /usr/bin/enable queue_name  
           # /usr/sbin/accept queue_name  

	 If you are using CUPS version 1.2 onward.
	   # /usr/sbin/cupsenable queue_name
	   # /usr/sbin/accept queue_name  

     Notes:
         a.  Replace queue_name with your actual queue name.
         b.  Replace printer_hostname with the printer's hostname or IP Address.
         c.  Replace 'Lexmark.ppd' with the appropriate 
             PPD filename.  See the following directory for available PPDs.

             /usr/share/cups/model/Lexmark_PPD

	     or 

             /usr/share/ppd/Lexmark_PPD
		

===============================================
3.  Print using CUPS command line print options 
===============================================

     A list of supported print queue options can be access by typing:
  
       # lpoptions -p queue_name -l

     Find the property name and value that you would like to change and
     add it to the lp print command.

       # lp -d queue_name -o property_name=property_value file_name

     For example, if you have a printer queue (lab_printer) that is currently
     set to print only single-sided pages, and you need to print a two-sided
     report, you can specify the change on the command line.

     First, determine if the printer queue supports the feature(s) you want
     to use (in this case, two-sided or duplex printing), and enter the 
     appropriate command. For this example, you would type: 

       # lpoptions -p lab_printer -l

     The lpoptions output would then include: 
     
       Duplex/Duplex: *None DuplexNoTumble DuplexTumble

     Find the property name and value that controls duplexing: 

       Duplex=DuplexNoTumble

     Type: 

       # lp -d lab_printer -o Duplex=DuplexNoTumble my_report.ps 


====================================================================
4.  Known Issues (Some issues may not be applicable to your printer)
====================================================================

   -----------------
   4.1  Localization.
   -----------------
   Localization is only supported on CUPS 1.2 or higher.
 
   Localization was tested using CUPS version 1.3.x

   ----------------------------------------------------------
   4.2  Printing text files with Red Flag 6.0 and Redhat 5.0.
   ----------------------------------------------------------
   When printing of text files with CUPS in Red Flag 6.0 and Redhat 5.0,
   make sure that the Paper Size setting in CUPS PPD is the same with the 
   setting in the Printer.
   
   -----------------------------------------
   4.3  Printing text files with Linpus 9.6.
   -----------------------------------------
   When printing text file with CUPS in Linpus 9.6, make sure that the
   said text file was saved using UTF-8 encoding.

   The said text file's encoding can be checked or changed using Text Editor
   application's File->Save As.  The following are the steps:
   1)  Launch Text Editor located at the Start menu's Accessories
   2)  Go to Text Editor's menubar and choose File->Save As
   3)  In the Save As dialog that was launched, look for the Character Coding
       dropdown list.  The said dropdown list will show what the encoding
       of the said text file is.
   4)  To change the encoding of the said text file to UTF-8, simply choose
       from the said dropdown list the UTF-8 option and click the Save button.  

   Another option to check or change the encoding of a text file is via the
   Terminal.
   To check the encoding of the said text file, simply type the command below
   in the Terminal:
                   file FILENAME_OF_TEXT_FILE

                   e.g.
                       file sample.txt

   To change the encoding of the said text file, simply type the command below
   in the Terminal:
                   iconv -f ORIGINAL_ENCODING_OF_TEXT_FILE -t NEW_ENCODING_OF_
                   TEXT_FILE < FILENAME_OF_TEXT_FILE > NEW_FILENAME_OF_
                   TEXT_FILE

                   e.g.
                       iconv -f ISO88592 -t UTF-8 < sample.txt > newsample.txt

   ---------------------------------------------------------
   4.4  Printing using Print and Hold option and Fax option.
   ---------------------------------------------------------
   Printing using Print and Hold option and Fax option only works via command line
   and via CUPS web interface, it doesn't not work via an application.

   Also take note that Print and Hold option and Fax option is only supported in 
   CUPS version 1.4 and higher.  Please use PPD file found in GlobalPPD_1.4 
   directory of the driver package for Print and Hold option and Fax option.   

   The following are the steps to print using Print and Hold option and Fax option
   via CUPS web interface:
   1)  Launch CUPS web interface (http://localhost:631) via an internet browser 
       (e.g. Firefox).
   2)  From the CUPS web interface, go to Printers tab and select the printer
       queue where you want to sent Print and Hold or Fax print job.
   3)  From the said printer queue's Administration dropdown list, 
       select Set Default Options then select JCL. 

   The following are the steps to print using Print and Hold option and Fax option
   via command line:
   1)  Launch Terminal.
   2)  Check available options for Print and Hold option and Fax option by typing
       the command below in Terminal:
            
            lpoptions -d PRINTER_QUEUE_NAME -l

            e.g.
                lpoptions -d myprinter -l
   3)  From the listed options, look for the PnH keyword for Print and Hold options 
       and the FaxNumber for Fax options.
   4)  To sent Print and Hold or Fax print job, type the following command in Terminal:
       4.1)  For Print and Hold (Verify, Repeat, Reserve):
             
             lp -d PRINTER_QUEUE_NAME -o PnH=PRINT_AND_HOLD_OPTION FILE

             e.g.
                 lp -d myprinter -o PnH=Verify sample.txt
       4.2)  For Print and Hold (Custom.PASSCODE):
           
             lp -d PRINTER_QUEUE_NAME -o PnH=Custom.PASSCODE FILE

             where:
                   PASSCODE is any 4-digit Pin number

             e.g.
                 lp -d myprinter -o PnH=Custom.1234 sample.jpg    
       4.3)  For Fax:

             lp -d PRINTER_QUEUE_NAME -o FaxNumber=FAX_OPTION FILE

             e.g.
                 lp -d myprinter -o FaxNumber=Custom.STRING sample.txt   
         
             where:
                   STRING is the fax number 

   ---------------------------------------
   4.5  Printing using Custom paper sizes.
   ---------------------------------------
   When printing using Custom paper sizes, please make sure to do the following
   on the actual printer before printing:
   1)  Go to Paper Menu->Paper Size/Type, one of the trays should be set
       to "Universal" paper size.  (e.g. set Tray 1 size to Universal)
   2)  Go to Paper Menu->Universal Setup, set units of measurement,
       width, and height to the same as that of the Custom paper to use for printing.
       (e.g. If Custom paper to use is Custom.5x7in, printer's Universal setup should
             also have inches as the value for its units of measurement, 5 as the value
             for its width, and 7 as the value for its height) 
   
   --------------------------------------------------------------------------
   4.6  Printing via the Commandline on OS with CUPS 1.4 and higher.
   --------------------------------------------------------------------------
   When printing via the Commandline on OS with CUPS 1.4 and higher,
   user needs to specify the fit-to-page option:
   lp -d PRINTER_QUEUE_NAME -o fit-to-page -o PageSize=PAPER_SIZE FILE
       
       where:
             PAPER_SIZE is the actual size of the paper where user prints

       e.g.
           lp -d myprinter -o fit-to-page -o PageSize=Legal sample.txt

   --------------------------------------------------------------------------
   4.7  Printing on OS with CUPS 1.1 and below.
   --------------------------------------------------------------------------
   When printing on OS with CUPS 1.1 and below, please make sure to do the following:
   1) Go to the Printer Configuration/Print Tool menu and select print queue to be used
   2) Click on the Edit button or right-click on the print queue and select Edit
   3) Once the edit menu launches, select the Queue Option tab
   4) In the Filter Option table at the bottom of the tab, set the given options below
      depending on your desired PageSize.

      If Borderless/FullBleed:
          page-bottom = 0
          page-right = 0
          page-left = 0
          page-top = 0

      If Non-Borderless:
          page-bottom = 12
          page-right = 12
          page-left = 12
          page-top = 12

   --------------------------------------------------------------------------
   4.8  Printing PDF file on Fedora OS with CUPS 1.4.3 and higher.
   --------------------------------------------------------------------------
   When Printing PDF file on Fedora OS with CUPS 1.4.3 and higher, please use
   an application (e.g. Adobe Reader and Adobe PhotoDeluxe Product brochure).
   
   --------------------------------------------------------------------------
   4.9  Printing via the Commandline and Collate option
   --------------------------------------------------------------------------
   When printing files through the commandline on Ubuntu 9.04 or later, the
   collate option can only be set to Off through the CUPS web interface.
   
   --------------------------------------------------------------------------
   4.10  Printing documents with OpenOffice 3.2
   --------------------------------------------------------------------------
   When printing documents in OpenOffice 3.2, users may have a problem printing
   onto a paper size that is different compared to what is set in the document's
   page settings (e.g. trying to print a Legal size printout set in the Print
   dialog while the document's page size is originally Letter). To successfully
   print into the desired paper size, the document's page size must be set correctly.
   
   	1. Create/open the document you wish to print.
   	2. Go to Format > Page...
   	3. Select the Page tab.
   	4. Under Paper Format, change the Format field into the desired paper size.
   	5. Click OK.
   
   --------------------------------------------------------------------------
   4.11  Printing Adobe PS 3.0 files using Document Viewer on Ubuntu 10.10
   --------------------------------------------------------------------------
   When printing Adobe PS files with file version 3.0 using the Document Viewer
   application on Ubuntu 10.10, users may not be able to print them in a page size
   that is different from the actual size of the document (e.g. trying to print
   a Legal size printout set in the Print dialog while the document's page size
   is originally Letter). To successfully print into the desired paper size, do
   the following:
   
   	1. Launch the Terminal application.
   	2. In the command prompt, type the following:
   	
   	   # lp -d <printername> -o PageSize=<size> <file>

   ----------------------------------------------------------
   4.12  Possible solution for a print output that is clipped.
   ----------------------------------------------------------
   When the print output is clipped, please try to do the following possible
   solutions:
   1.  Specify the fit-to-page option:
       a.  Through the application that was used when the said clipped output was
           encountered.
 
           or
 
       b.  Through the commandline using the lp command below:
           lp -d PRINTER_QUEUE_NAME -o fit-to-page -o PageSize=PAPER_SIZE FILE
 
           where:
                 PAPER_SIZE is the actual size of the paper where user prints
 
           e.g.
               lp -d myprinter -o fit-to-page -o PageSize=Legal sample.txt
 
   or
 
   2.  Specify the scaling option:
       a.  Through the application that was used when the said clipped output was
           encountered.

           or
 
       b.  Through the commandline using the lp command below:
           lp -d PRINTER_QUEUE_NAME -o scaling=100 -o PageSize=PAPER_SIZE FILE
 
           where:
                 PAPER_SIZE is the actual size of the paper where user prints
 
           e.g.
               lp -d myprinter -o scaling=100 -o PageSize=Legal sample.txt
               
               
   -----------------------------------------------------------
   4.13  Printing files with Mirror option activated
   -----------------------------------------------------------
   When printing files with the LexMirror option activated, there may be cases that
   the output is not flipped in a mirror manner. If this happens, use any of the following
   workaround options:
       - use the Mirror option instead of LexMirror when printing via commandline.
         the option will look like 'Mirror=True'. This option is applicable when you
         are printing via commandline. If you are printing through an application,
         you need to save the file you intend to print as PDF, then print the file
         using the lp command.
         
         e.g. lp -d <printerName> -o Mirror=True <fileName>
         
         
       - set the Mirror option as default in CUPS web.
       
