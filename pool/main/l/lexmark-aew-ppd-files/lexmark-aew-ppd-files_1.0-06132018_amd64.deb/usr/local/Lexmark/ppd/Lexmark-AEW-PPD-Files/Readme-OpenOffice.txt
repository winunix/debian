
=================
Table of Contents
=================

   1. Configuring StarOffice and OpenOffice Printers
      ----------------------------------------------
      1.1  StarOffice and OpenOffice Versions 1.1.2 or older
      1.2  OpenOffice Versions 1.1.3 and newer
 
   2. Known Issues
      ------------
      2.1  Paper Size and Orientation does not work


=================================================
1. Configuring StarOffice and OpenOffice Printers
=================================================

   ------------------------------------------------------
   1.1  StarOffice and OpenOffice Versions 1.1.2 or older
   ------------------------------------------------------
   StarOffice and OpenOffice version 1.1.2 or older require a PPD to be 
   manually configured in order to take advantage of printer specific 
   options.  

   Note: Your steps may be slightly different depending on your 
         StarOffice and OpenOffice version.

     1.  Create a print queue using the OS provided print tools.
        
         For Example: CUPS Web, SuSE YaST, Red Hat printool, etc.

     2.  Add a PPD file and associate it with a queue.

         A.  Start spadmin by typing the following command.

             Red Hat : /usr/lib/openoffice.org1.1/program/spadmin
             SuSE    : /opt/OpenOffice.org/spadmin

         B.  Setup your printer.

             a.  Select the New Printer button.

             b.  Select 'Add a printer' and then Next.

             c.  If your printer is listed, skip to step g.

             d.  If your printer is not listed, select Import.

             e.  Select the browse button and select the directory where 
                 you untarred the PPD package and it includes the actual
                 PPD files:  
                 Example:  
                          For CUPS version lower than 1.4, use the PPD
                          file found in ppd_files/GlobalPPD_1.2.

                          For CUPS version 1.4 and higher, use the PPD
                          file found in ppd_files/GlobalPPD_1.4.

             f.  Select your printer model for the 'Selection of drivers' 
                 box and select OK.

             g.  From the 'Please select a suitable driver' box, select 
                 your printer model and press next.

             h.  Enter your print command in the command line field.  If you 
                 are using CUPS, enter 'lp -d queuename' and replace 
                 queuename with the queuename you created in step 1.  Then 
                 select Finish.

         C.  If you want this printer to be the default, select the 
             appropriate one and select default.

         D.  Click Close to exit spadmin.

     3.  Restart StarOffice and OpenOffice to pick up the changes.
       
   -----------------------------------
   1.2  OpenOffice Versions 1.1.3 and newer
   -----------------------------------
   OpenOffice version 1.1.3 and newer no longer require a PPD to be 
   manually configured when using a CUPS based print queue.   Just simply 
   create a CUPS PPD queue and OpenOffice will automatically provide you 
   with the printer specific options based on PPD associated with the 
   print queue.


===============
2. Known Issues
===============

   -----------------------------------------------
   2.1  Paper Size and Orientation does not work
   -----------------------------------------------
   This is normal behavior for StarOffice and OpenOffice.  To enable these
   options, you must enable 'Printer Warning' in the Options windows.
 
     1.  Start StarOffice or OpenOffice.
     
     2.  Select Tools from the Menu bar and then select Options.
  
     3.  Select 'Print' from the tree and check the 'Paper size' and 
         'Paper orientation' check boxes under the Printer Warning section.
  
     4.  Select OK.

   Now paper size and orientation options should work correctly.
