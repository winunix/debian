                                    Version 1.0.0

=================
Table of Contents
=================

   1.  Driver installation and upgradation options
       1.1  Installation and Upgradation using the .tar.Z package
       1.2  Installation and Upgradation using the .deb package
       1.3  Installation and Upgradation using the .rpm package

   2.  Driver uninstallation options
       2.1  Uninstallation if .tar.Z was used to install the package
       2.2  Uninstallation if .deb was used to install the package
       2.3  Uninstallation if .rpm was used to install the package

   3. Notes

** Some install options may not be applicable to your package. Refer to the
package filename extension that you have. It may be .tar.Z, .deb, or .rpm.


==============================
1. Driver installation and upgradation options
==============================

   Choose your installation or upgradation method depending on the type of package
   you downloaded.
   

==========================================
1.1  Installation and Upgradation using the .tar.Z package
==========================================

  1.  Download the file.

  2.  If the package file is compressed, then extract the file by typing the
      command:

        uncompress Lexmark-AEW-PPD-Files.tar.Z

  3.  Untar the file in this directory via:

        tar -xvf Lexmark-AEW-PPD-Files.tar

  4.  Change to the ppd_file directory via:

        cd ppd_files

  5.  Install the PPD files.

      a. Linux-Based CUPS
         ----------------
         Log in as a root user and then run the install script:

         ./install_ppd.sh

         See the Readme-CUPS.txt file for more information.

      b. Other CUPS installations
         ------------------------
         Copy the appropriate PPDs into the CUPS model directory 
         and restart CUPS.

         For CUPS version earlier than 1.4, use the PPD file(s) found in 
         ppd_files/GlobalPPD_1.2.

         For CUPS version 1.4 or later, use the PPD file(s) found in 
         ppd_files/GlobalPPD_1.4.

      c. OpenOffice/StarOffice
         -----------------------
         See the Readme-OpenOffice.txt file for more information.

      d. Other applications
         ------------------
         See the application documentation.


========================================
1.2  Installation and Upgradation using the .deb package
========================================

  1.  Download the file.

  2.  Install or Upgrade the package either by double-clicking the icon or through 
      the terminal using the following command:

      For 32-bit systems:
        dpkg -i Lexmark-AEW-PPD-Files-1.0-i386.deb

      For 64-bit systems:
        dpkg -i Lexmark-AEW-PPD-Files-1.0-amd64.deb

      Note: Administrative or 'root' access may be needed during the
            installation and upgradation. You must have access to any of these accounts
            when prompted.

  Installation or Upgradation is complete.


========================================
1.3  Installation and Upgradation using the .rpm package
========================================

  1.  Download the file.

  2.  Install or Upgrade the package either by double-clicking the icon or through 
      the terminal using the following command:
		
		a. For Installation
			For 32-bit systems:
			rpm -ivh Lexmark-AEW-PPD-Files-1.0-i386.rpm

			For 64-bit systems:
			rpm -ivh Lexmark-AEW-PPD-Files-1.0-x86-64.rpm
		
		b. For Upgradation
			For 32-bit systems:
			rpm -Uvh Lexmark-AEW-PPD-Files-1.0-i386.rpm

			For 64-bit systems:
			rpm -Uvh Lexmark-AEW-PPD-Files-1.0-x86-64.rpm
		
      Note: Administrative or 'root' access may be needed during the
            installation or upgradation. You must have access to any of these accounts
            when prompted.

  Installation or Upgradation is complete.


=================================
2.  Driver uninstallation options
=================================

   Choose your uninstallation method depending on the type of installation or upgradation
   you used to install or Upgrade the driver software.


=============================================================
2.1  Uninstallation if .tar.Z was used to install the package
=============================================================

   If you chose to install the driver software using the Lexmark-AEW-PPD-Files.tar.Z
   package, then you need to manually remove the following files:

   a. Common UNIX Print Subsystem (CUPS)
      ----------------------------------
      Delete the PPD files from the following locations (if they exist) and restart CUPS.

        /usr/share/ppd/Lexmark_PPD/*
        /usr/share/cups/model/Lexmark_PPD/*
      

   b. Printer configuration (printtool or printconf) and Foomatic utilities
      ---------------------------------------------------------------------
      Delete the following files.
        
        /usr/share/foomatic/db/source/driver/Lexmark_PPD.xml 
        /usr/share/foomatic/db/source/opt/ppd-Lexmark_*
        /usr/share/foomatic/db/source/printer/Lexmark_*


===========================================================
2.2  Uninstallation if .deb was used to install the package
===========================================================

   Using your OS package manager, select the name of the package that
   you installed and remove it, or use the terminal by typing the
   following command:

      dpkg -r Lexmark-AEW-PPD-Files


===========================================================
2.3  Uninstallation if .rpm was used to install the package
===========================================================

   Using your OS package manager, select the name of the package that
   you installed and remove it, or use the terminal by typing the
   following command:

   For 32-bit systems:
        rpm -e Lexmark-AEW-PPD-Files-1.0.i386

   For 64-bit systems:
        rpm -e Lexmark-AEW-PPD-Files-1.0.x86_64

   If these commands do not work because the architecture is not present in
   the package name, then use the following command:
        rpm -e Lexmark-AEW-PPD-Files-1.0


=========
3. Notes:
=========

  1.Supported Languages
  ---------------------

English (en)
 French (fr)
 German (de)
 Italian (it)
 Spanish (es)
 Korean (ko)
 Japanese (ja)
 Russian (ru)
 Polish (pl)
 Brazilian Portuguese (pt)
 Traditional Chinese (zh_TW) 
 Simplified Chinese (zh_CN)



  2.Supported Operating Systems
  -----------------------------

     Red Hat Enterprise Linux WS 7
     Red Hat Enterprise Linux WS 6
     openSUSE Linux 42.2
     openSUSE Linux 13.2
     SUSE Linux Enterprise Server 12 
     SUSE Linux Enterprise Server 11 
     Debian GNU/Linux 8
     Debian GNU/Linux 7 
     Ubuntu 16.10
     Ubuntu 15.10
     Ubuntu 14.04 
     Ubuntu 12.04
     Fedora 25
     Fedora 24


  3.File Names
  -----------------------------


     Printer Type                       Globalized PPD
     ------------                       ------------------

     Lexmark MS820 Series                 Lexmark_MS820_Series.ppd

     Lexmark MB2700 Series                Lexmark_MB2700_Series.ppd

     Lexmark MS725 Series                 Lexmark_MS725_Series.ppd

     Lexmark MX720 Series                 Lexmark_MX720_Series.ppd

     Lexmark MX725 Series                 Lexmark_MX725_Series.ppd

     Lexmark MX820 Series                 Lexmark_MX820_Series.ppd

     Lexmark M5200 Series                 Lexmark_M5200_Series.ppd

     Lexmark XM5300 Series                Lexmark_XM5300_Series.ppd

     Lexmark XM7300 Series                Lexmark_XM7300_Series.ppd

     Lexmark B2860 Series                 Lexmark_B2860_Series.ppd
